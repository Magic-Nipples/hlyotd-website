
ABOUT:
This is an old alpha build of Half-Life: Year of the Dragon from September 7th, 2018. Later patched on the 8th with very minor bug fixes.
The mod was played live for the r/Spyro 20th Anniversary Charity Stream on the 9th of September. You can view that here:
https://youtu.be/rxeyMTBegnw


INSTALL:
Copy the "Valve" folder to where this .txt file is. It should be located here:
[your drive letter] :\Program Files (x86)\Steam\steamapps\common\Half-Life


NOTES:
This build is by no means finished, and does not reflect the current state of the mod. I was still figuring out how to get Spyro's mechanics
in at the time so many things feel clunky, or flat out don't work right.

I'm mainly uploading this so anyone can see what the mod was like during that time. A lot changed between this build and the demo that 
released the following month and some people may find that interesting so here's to those curious people!

I packaged AntiMicro with this demo since controller support did not exist at the time, or atleast good controller support. It's optimal
to just play this with a mouse and keyboard anyways so I don't recommend using a controller with this honestly.

The maps are just slightly modified retail maps with entrip to change some things around. I didn't have map sources at the time so editing 
maps was pretty much impossible.


Thanks for actually reading this, you are a cool!